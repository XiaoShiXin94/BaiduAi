﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BaiduAi
{
    public class GetBaiduToken
    {
        public string GetAccessToken(string client_id, string secret)
        {
            String authHost = "https://aip.baidubce.com/oauth/2.0/token";
            HttpClient client = new HttpClient();
            List<KeyValuePair<String, String>> paraList = new List<KeyValuePair<string, string>>();
            paraList.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));
            paraList.Add(new KeyValuePair<string, string>("client_id", client_id));
            paraList.Add(new KeyValuePair<string, string>("client_secret", secret));

            HttpResponseMessage response = client.PostAsync(authHost, new FormUrlEncodedContent(paraList)).Result;
            String result = response.Content.ReadAsStringAsync().Result;

            var objToken = JsonConvert.DeserializeObject<JObject>(result);
            string token = String.Empty;
            if (objToken != null)
            {
                token = objToken["access_token"].ToString();
            }
            return token;
        }
    }
}
