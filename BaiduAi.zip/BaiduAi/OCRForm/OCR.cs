﻿using BaiduAi.OCRForm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiduAi
{
    public partial class OCR : Form
    {
        public OCR()
        {
            InitializeComponent();
        }
        BaiduOCR BiduOCR = new BaiduOCR();
        string OCRclientId = ConfigurationManager.AppSettings["OCRClientId"];
        string OCRclientSecret = ConfigurationManager.AppSettings["OCRClientSecret"];
        string TranslateClientId = ConfigurationManager.AppSettings["TranslateClientId"];
        string TranslateClientSecret = ConfigurationManager.AppSettings["TranslateClientSecret"];
        private void Form1_Load(object sender, EventArgs e)
        {
            if (OCRclientId=="" && OCRclientSecret=="")
            {
                SetKey setKey = new SetKey();
                setKey.FormText = "文字识别";
                setKey.Lable2Text = "通用文字识别（标准含位置版）";
                setKey.ShowDialog();
                return;
            }
            if (TranslateClientId == "" && TranslateClientSecret == "")
            {
                SetKey setKey = new SetKey();
                setKey.FormText = "文本翻译";
                setKey.Lable2Text = "文本翻译-通用版";
                setKey.ShowDialog();
                return;
            }
        }
        PictureBox pictureBox1 =new PictureBox();
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowHelp = false;//设置是否显示"帮助"按钮
            openFileDialog1.InitialDirectory = "C:\\Users\\Administrator\\Pictures\\";//设置初始目录为桌面
            openFileDialog1.Title = "选择图片";//设置对话框的标题
            openFileDialog1.FileName = "";//设置初始选择的文件名为空
            openFileDialog1.Multiselect = false;//设置对话框为单选
            openFileDialog1.Filter = "选择图片|*.*|JPEG图片|*.jpeg|PNG图片|*.png|JPG图片|*.jpg|BMP图片|*.bmp"; //筛选文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txt_Url.Text = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                if (txt_Url.Text != "")
                {
                    ImgFileStreamIO(txt_Url.Text);
                    BiduOCR.GetImgCharacters(txt_Url.Text, pictureBox1);
                }
                openFileDialog1.Dispose();
            }
            else
            {
                txt_Url.Text = "";
            }
        }
        //获取拖动到文本框上文件的路径
        private void txt_Url_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        //拖动文件到文本框
        private void txt_Url_DragDrop_1(object sender, DragEventArgs e)
        {
            txt_Url.Text = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            FileInfo t = new FileInfo(txt_Url.Text);
            //string size = GetFileSize(t.Length);
            if (t.Length > 1000000)
                MessageBox.Show("图片大小超过服务器限制，建议1MB以下");
            else
            if (txt_Url.Text != "")
            {
                //richTextBox1.Text = String.Empty;
                ImgFileStreamIO(txt_Url.Text);
                BiduOCR.GetImgCharacters(txt_Url.Text, pictureBox1);
            }
        }
        public void ImgFileStreamIO(string path)
        {
            System.IO.FileStream fs = new System.IO.FileStream(path, FileMode.Open, FileAccess.Read);
            int byteLength = (int)fs.Length;
            byte[] fileBytes = new byte[byteLength];
            fs.Read(fileBytes, 0, byteLength);
            //文件流关闭,文件解除锁定
            fs.Close();
            MemoryStream mStream = new MemoryStream(fileBytes);
            Image image = Image.FromStream(mStream);
            pictureBox1.Image = image;
        }
        private void 截图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cut cut = new Cut();
            cut.Show();
        }
        private void 设置文字识别ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetKey setKey = new SetKey();
            setKey.FormText = "文字识别";
            setKey.Lable2Text = "通用文字识别（标准含位置版）";
            setKey.Show();
        }

        private void 设置文字翻译ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetKey setKey = new SetKey();
            setKey.FormText = "文字翻译";
            setKey.Lable2Text = "文本翻译-通用版";
            setKey.Show();
        }
    }
}
