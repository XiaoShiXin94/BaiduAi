﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace BaiduAi
{
    public partial class Cut : Form
    {
        public Cut()
        {
            InitializeComponent();
        }
        bool mouseDown = false, havePainted = false;
        Point start, end;
        Point start1, end1;
        Size size = new Size(0, 0);
        private void ReadyToCaptrue()
        {
            this.BackColor = Color.Black;
            this.Opacity = 0.08;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
        }
        private void Cut_Load(object sender, EventArgs e)
        {
            ReadyToCaptrue();
        }
        private void Cut_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                if (size.Width != 0 && size.Height != 0 && havePainted)
                {
                    ControlPaint.DrawReversibleFrame(new Rectangle(start1, size), Color.Transparent, FrameStyle.Dashed);
                }
                end1 = e.Location;
                size.Width = Math.Abs(end1.X - start.X);
                size.Height = Math.Abs(end1.Y - start.Y);
                start1.X = (start.X > end1.X) ? end1.X : start.X;
                start1.Y = (start.Y > end1.Y) ? end1.Y : start.Y;

                if (size.Width != 0 && size.Height != 0)
                {
                    ControlPaint.DrawReversibleFrame(new Rectangle(start1, size), Color.Transparent, FrameStyle.Dashed);
                    havePainted = true;
                }
            }
        }
        private void Cout_MouseDown(object sender, MouseEventArgs e)
        {
            start = e.Location;
            mouseDown = true;
        }
        private void Cout_MouseUp(object sender, MouseEventArgs e)
        {
            if (size.Width != 0 && size.Height != 0)
            {
                ControlPaint.DrawReversibleFrame(new Rectangle(start1, size), Color.Transparent, FrameStyle.Dashed);
                havePainted = false;
            }
            end = e.Location;
            if (start.X > end.X)
            {
                int temp = end.X;
                end.X = start.X;
                start.X = temp;
            }
            if (start.Y > end.Y)
            {
                int temp = end.Y;
                end.Y = start.Y;
                start.Y = temp;
            }
            Thread.Sleep(200);
            if (end.X - start.X > 0 && end.Y - start.Y > 0)
            {
                Bitmap bit = new Bitmap(end.X - start.X, end.Y - start.Y);
                Graphics g = Graphics.FromImage(bit);
                g.CopyFromScreen(start, new Point(0, 0), bit.Size);
                Clipboard.SetImage(bit);
                this.Close();
                g.Dispose();
            }
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Hide();
            this.Opacity = 0.1;
            mouseDown = false;
            BaiduOCR baiduOCR = new BaiduOCR();
            baiduOCR.GetCutImgCharacters(Clipboard.GetImage());
        }
    }
}
