﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiduAi
{
    public partial class OCR : Form
    {
        public OCR()
        {
            InitializeComponent();
        }
        BaiduOCR BiduOCR = new BaiduOCR();
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        PictureBox picb = new PictureBox();
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowHelp = false;//设置是否显示"帮助"按钮
            openFileDialog1.InitialDirectory = "C:\\Users\\Administrator\\Desktop\\";//设置初始目录为桌面
            openFileDialog1.Title = "选择图片";//设置对话框的标题
            openFileDialog1.FileName = "";//设置初始选择的文件名为空
            openFileDialog1.Multiselect = false;//设置对话框为单选
            openFileDialog1.Filter = "选择图片|*.*|JPEG图片|*.jpeg|PNG图片|*.png|JPG图片|*.jpg|BMP图片|*.bmp"; //筛选文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txt_Url.Text = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                openFileDialog1.Dispose();
            }
            richTextBox1.Text = String.Empty;
            BiduOCR.GetImgCharacters(txt_Url.Text, richTextBox1);
        }

        //获取拖动到文本框上文件的路径
        private void txt_Url_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        //拖动文件到文本框
        private void txt_Url_DragDrop_1(object sender, DragEventArgs e)
        {
            richTextBox1.Text = String.Empty;
            txt_Url.Text = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            FileInfo t = new FileInfo(txt_Url.Text);
            //string size = GetFileSize(t.Length);
            if (t.Length > 1000000)
                MessageBox.Show("图片大小超过服务器限制，建议1MB以下");
            else
            BiduOCR.GetImgCharacters(txt_Url.Text, richTextBox1);
        }
    }
}
